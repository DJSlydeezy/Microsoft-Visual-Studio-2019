<!--
title: "Read documentation on <https://learn.netdata.cloud>"
custom_edit_url: https://github.com/netdata/netdata/edit/master/docs/README.md
-->

# Read documentation on <https://learn.netdata.cloud>

Welcome to the Netdata documentation! While you can read Netdata documentation here, or throughout the Netdata
repository, our intention is that these pages are read on [learn.netdata.cloud](https://learn.netdata.cloud). 

Links between documentation pages will work fine here, but the formatting may not be perfect, as our documentation site
uses a few extra Markdown features that GitHub doesn't support natively. Other things might be missing or look less than
perfect.

Now get out there and build an exceptional infrastructure.

[![analytics](https://www.google-analytics.com/collect?v=1&aip=1&t=pageview&_s=1&ds=github&dr=https%3A%2F%2Fgithub.com%2Fnetdata%2Fnetdata&dl=https%3A%2F%2Fmy-netdata.io%2Fgithub%2Fdocs%2FREADME&_u=MAC~&cid=5792dfd7-8dc4-476b-af31-da2fdb9f93d2&tid=UA-64295674-3)](<>)
