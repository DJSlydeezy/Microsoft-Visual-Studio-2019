<!--
title: "Add more charts to Netdata"
custom_edit_url: https://github.com/netdata/netdata/edit/master/docs/Add-more-charts-to-netdata.md
-->

# Add more charts to Netdata

This file has been deprecated. Please see our [collectors docs](/collectors/README.md) or the collectors [quickstart
guide](/collectors/QUICKSTART.md) for more information. 

## Available data collection modules

See the [list of supported collectors](/collectors/COLLECTORS.md) to see all the sources Netdata can collect metrics
from.

[![analytics](https://www.google-analytics.com/collect?v=1&aip=1&t=pageview&_s=1&ds=github&dr=https%3A%2F%2Fgithub.com%2Fnetdata%2Fnetdata&dl=https%3A%2F%2Fmy-netdata.io%2Fgithub%2Fdocs%2FAdd-more-charts-to-netdata&_u=MAC~&cid=5792dfd7-8dc4-476b-af31-da2fdb9f93d2&tid=UA-64295674-3)]()
